local bot = require('bot')

local instance = {}

return bot.run(instance)
