return {

	-- Your authorization token from the botfather.
	bot_api_key = '248343935:AAHnRmcry_Q_lKj6LlCOio4MQTEIynHhsz0',
	-- Your Telegram ID.
	admin = 261413397,
	about_text = [[
انا بوت سمسمي المتكلم
تكلم معي وسوف اقوم
بالرد عليك تحذيررر
ممنوع السب مع البوت
♦️♦️♦️♦️♦️♦️♦️♦️♦️♦️♦️♦️
	]],
	simsimi_key = '41250a68-3cb5-43c8-9aa2-d7b3caf519b1', 
	lang = 'ar','en','af','bg','ca','ch','cs','cy','da','de','el','es','eu','fi','fr','he','hi','hr','hu','id','it','ja','kh','ko','lt','ml','ms','nb','nl','pa','ph','pl','pt','ro','rs','ru','sk','sv','ta','te','th','tr','uk','vn','zh',
	
	langer = true,
	
	errors = {connection = 'Connection error.',results = 'No results found.',argument = 'Invalid argument.',syntax = 'Invalid syntax.',chatter_connection = 'I don\'t feel like talking right now.',chatter_response = 'I don\'t know what to say to that.'},

	plugins = {'simsimi','help','about','control'}

}
