#!/bin/sh

#while true; do
#	lua main.lua
#	echo 'stopped.the bot :|\n---------------\n'
#	sleep 5s
#done
lua main.lua